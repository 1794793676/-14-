/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "adc.h"
#include "tim.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "lcd.h"
#include "stdio.h"
#include "string.h"
#include "stdbool.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define pi 3.14
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
/**********************************************************************************/
//GLOBLE
bool Flag_isHigh = false;
uint8_t R=1,K=1;
uint8_t temp_R,temp_K;
uint16_t PWM_cnt;
uint8_t* choice = &R;
bool isLock = false;
bool isR = true;
//PV_LED
uint32_t LED_delay_ms;
//PV_Key
uint8_t key_now;
uint8_t key_down;
uint8_t key_up;
uint8_t key_old;
uint32_t Key_count_ms;
uint32_t Key_PWM_ms;
	uint8_t page = 1;
	bool flag_1 = true;
//PV_LCD
char LCD_buf[21];
char LCD_temp_buf[21];
char LCD_Line5_buf[21];
uint16_t LCD_Flash_time;
//PV_TIM2
extern int TIM2_PSC_now;
extern uint32_t PSC_Time;
//PV_ADC
double Volt_R37=0;
uint8_t set_pwm_duty ;
uint8_t temp_pwm_duty=1;
//PV_TIM17
double frq;
double speed;
extern int TIM17_PSC_now;
uint32_t capture;
/**********************************************************************************/
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */
/**********************************************************************************/
//PFP_LED
void LED_Light(uint16_t GPIO_Pin);
void LED_OFF(void);
void LED_Flash(uint16_t GPIO_Pin, uint16_t ms);
void LED_Dark(uint16_t GPIO_Pin);
//PFP_KEY
void Key_Pj(void);
uint8_t Key_Read(void);
//PFP_LCD
void Show_Page_1(void);
void Show_Page_2(void);
void Show_Page_3(void);
void LCD_Show(uint8_t page);
//PFP_ADC
double Get_Volt_R37(void);
void Set_PWM_Duty(void);
//PFP_TIM17
//void HAL_TIM_IC_CaptureCallback(TIM_HandleTypeDef *htim);
//double Get_Speed_PA7(void);
/**********************************************************************************/
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */
	LCD_Init();
	LCD_SetBackColor(Black);
  LCD_SetTextColor(White);
	LCD_Clear(Black);
  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_ADC2_Init();
  MX_TIM2_Init();
  MX_TIM17_Init();
  /* USER CODE BEGIN 2 */
	LED_OFF();
	Show_Page_1();
	HAL_TIM_IC_Start_IT(&htim17,TIM_CHANNEL_1);
	TIM2_PSC_now = TIM2->PSC;
	TIM17_PSC_now = TIM17->PSC;
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
		Key_Pj();
		Get_Volt_R37();
		Set_PWM_Duty();	
			sprintf(LCD_Line5_buf,"     V=%.1f",speed );
	LCD_DisplayStringLine(Line5,(u8*)LCD_Line5_buf);
		//Get_Speed_PA7();	
		if(strcmp(LCD_temp_buf,LCD_buf) != 0 && temp_pwm_duty != set_pwm_duty){
			LCD_Show(page);
			strcpy(LCD_temp_buf,LCD_buf);
			temp_pwm_duty = set_pwm_duty;
			temp_R = R;temp_K = K;
		} 

  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = RCC_PLLM_DIV3;
  RCC_OscInitStruct.PLL.PLLN = 20;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = RCC_PLLQ_DIV2;
  RCC_OscInitStruct.PLL.PLLR = RCC_PLLR_DIV2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

/* LED
************************************************************
void LED_Light(uint16_t GPIO_Pin);
void LED_OFF(void);
void LED_Flash(uint16_t GPIO_Pin, uint16_t ms);
void LED_Dark(uint16_t GPIO_Pin);
************************************************************
*/
void LED_OFF(void){
	HAL_GPIO_WritePin(GPIOC,0XFF<<8,GPIO_PIN_SET);
	HAL_GPIO_WritePin(GPIOD,GPIO_PIN_2,GPIO_PIN_SET);
	HAL_GPIO_WritePin(GPIOD,GPIO_PIN_2,GPIO_PIN_RESET);
}
void LED_Light(uint16_t GPIO_Pin){
	LED_OFF();
	HAL_GPIO_WritePin(GPIOC,GPIO_Pin,GPIO_PIN_RESET);
	HAL_GPIO_WritePin(GPIOD,GPIO_PIN_2,GPIO_PIN_SET);
	HAL_GPIO_WritePin(GPIOD,GPIO_PIN_2,GPIO_PIN_RESET);
}
void LED_Dark(uint16_t GPIO_Pin){
	HAL_GPIO_WritePin(GPIOC,GPIO_Pin,GPIO_PIN_SET);
	HAL_GPIO_WritePin(GPIOD,GPIO_PIN_2,GPIO_PIN_SET);
	HAL_GPIO_WritePin(GPIOD,GPIO_PIN_2,GPIO_PIN_RESET);
}
void LED_Flash(uint16_t GPIO_Pin, uint16_t ms){	
	LED_Light(GPIO_PIN_8);
	if(LED_delay_ms>=ms){
		LED_delay_ms = 0;
		HAL_GPIO_TogglePin(GPIOC, GPIO_PIN_10);
		HAL_GPIO_WritePin(GPIOD,GPIO_PIN_2,GPIO_PIN_SET);
		HAL_GPIO_WritePin(GPIOD,GPIO_PIN_2,GPIO_PIN_RESET);
	}
}

/* Key
************************************************************
void Key_Pj(void);
uint8_t Key_Read(void);
************************************************************
*/
uint8_t Key_Read(void){
	uint8_t key_val=0;
	if(HAL_GPIO_ReadPin(GPIOB,GPIO_PIN_0) == GPIO_PIN_RESET)	key_val = 1;
	if(HAL_GPIO_ReadPin(GPIOB,GPIO_PIN_1) == GPIO_PIN_RESET)	key_val = 2;
	if(HAL_GPIO_ReadPin(GPIOB,GPIO_PIN_2) == GPIO_PIN_RESET)	key_val = 3;
	if(HAL_GPIO_ReadPin(GPIOA,GPIO_PIN_0) == GPIO_PIN_RESET)	key_val = 4;
	return key_val;
}

void Key_Pj(void){
	key_now = Key_Read();		//��ȡ����ֵ
	key_down = key_now & (key_now^key_old);		//�½��ؼ��_˲��
	key_up =  ~key_now & (key_now^key_old);		//�����ؼ��_˲��
	key_old = key_now;		//��һ�ΰ���ֵ
	
	if(key_down){
		Key_count_ms = 0;
	}
	if(Key_count_ms>=2000){
		if(key_up == 4 && page == 1){
			if(isLock == false)	isLock = true;
			Show_Page_1();
		}
	}
	//Short
	else{
		if(key_up == 1){
			if(page++ == 3)	page = 1;
			LCD_Show(page);
		}
		if(key_up == 2){
			switch (page){
      	case 1:
						if(flag_1 || Key_PWM_ms>=5000){
						PWM_cnt++;
						Key_PWM_ms = 0;
						flag_1 = false;
						if(Flag_isHigh){			//mode_H
							Flag_isHigh = false;
							while(TIM2_PSC_now >=99 && TIM2_PSC_now !=199
								&&TIM17_PSC_now >=9999 && TIM2_PSC_now !=19999){
								while(PSC_Time>=5){
									LED_Flash(GPIO_PIN_9,100);
									PSC_Time = 0;
									TIM2_PSC_now++;
									TIM17_PSC_now += 100;
									htim2.Init.Prescaler = TIM2_PSC_now;
									htim17.Init.Prescaler = TIM17_PSC_now;
								}
							}
						}  
						else{			//mode_L
							Flag_isHigh = true;
							while(TIM2_PSC_now <=199 && TIM2_PSC_now !=99 
								&& TIM2_PSC_now <=19999 && TIM17_PSC_now !=9999){
								while(PSC_Time>=5){
									LED_Flash(GPIO_PIN_9,100);
									PSC_Time = 0;
									TIM2_PSC_now--;
									TIM17_PSC_now -= 100;
									htim2.Init.Prescaler = TIM2_PSC_now;
									htim17.Init.Prescaler = TIM17_PSC_now;
								}
							}
						}
						LED_OFF();
					}
					Show_Page_1();
				break;
      	case 2:
					if(isR)	isR = false;
					else isR = true;
				break;
      }
		}
		if(key_up == 3){
			if(isR){
				if(R++ == 10)	R=1;
			}
			else{
				if(K++ == 10)	K=1;
			}
			LCD_Show(page);
		}
		if(key_up == 4){
			switch (page){
      	case 1:
					if(isLock)	isLock = false;
      		break;
      	case 2:
					if(isR){
						if(R-- == 1)	R=10;
					}
					else{
						if(K-- == 1)	K=10;
					}
      		break;
      }
			LCD_Show(page);
		}
	}
}

/* LCD
************************************************************
void Show_Page_1(void);
void Show_Page_2(void);
void Show_Page_3(void);
void LCD_Show(uint8_t page);
************************************************************
*/
void Show_Page_1(void){
	LED_Light(GPIO_PIN_8);
	LCD_Clear(Black);
	sprintf(LCD_buf,"        DATA");
	LCD_DisplayStringLine(Line1,(u8*)LCD_buf);
	if(Flag_isHigh == false){
		sprintf(LCD_buf,"     M=L");
		LCD_DisplayStringLine(Line3,(u8*)LCD_buf);

	}
	else if(Flag_isHigh == true){
		sprintf(LCD_buf,"     M=H");
		LCD_DisplayStringLine(Line3,(u8*)LCD_buf);
	
	} 
	if(!isLock){
		sprintf(LCD_buf,"UNLOCK");
		LCD_DisplayStringLine(Line8,(u8*)LCD_buf);
	}
	else if(isLock == true){
		sprintf(LCD_buf,"LOCK");
		LCD_DisplayStringLine(Line8,(u8*)LCD_buf);
	}
	sprintf(LCD_buf,"     P=%d%%",set_pwm_duty);
	LCD_DisplayStringLine(Line4,(u8*)LCD_buf);	

	//
//	sprintf(LCD_buf,"TIM2_PSC:%d",TIM2_PSC_now);
//	LCD_DisplayStringLine(Line5,(u8*)LCD_buf);
//	sprintf(LCD_buf,"TIM17_PSC:%d",TIM17_PSC_now);
//	LCD_DisplayStringLine(Line6,(u8*)LCD_buf);
}
void Show_Page_2(void){
	LED_OFF();
	LCD_Clear(Black);
	sprintf(LCD_buf,"        PARA");
	LCD_DisplayStringLine(Line1,(u8*)LCD_buf);
	sprintf(LCD_buf,"     R=%d", R);
	LCD_DisplayStringLine(Line3,(u8*)LCD_buf);
	sprintf(LCD_buf,"     K=%d", K);
	LCD_DisplayStringLine(Line4,(u8*)LCD_buf);

}
void Show_Page_3(void){
	LCD_Clear(Black);
	sprintf(LCD_buf,"        RECD");
	LCD_DisplayStringLine(Line1,(u8*)LCD_buf);
	sprintf(LCD_buf,"     N=%d",PWM_cnt);
	LCD_DisplayStringLine(Line3,(u8*)LCD_buf);
}
void LCD_Show(uint8_t page){
	LED_OFF();
	switch(page){
		case 1:Show_Page_1();break;
		case 2:Show_Page_2();break;
		case 3:Show_Page_3();break;
	}
}

/* ADC
************************************************************
double Get_Volt_R37(void);
void Set_PWM_Duty(void);
************************************************************
*/
double Get_Volt_R37(void){
	HAL_ADC_Start(&hadc2);
	Volt_R37 = HAL_ADC_GetValue(&hadc2)*3.3/4096;
	return Volt_R37;
}
void Set_PWM_Duty(void){
	if(Get_Volt_R37()<=1)	set_pwm_duty = 10;
	else if(Get_Volt_R37()>=3)	set_pwm_duty = 85;
	else	set_pwm_duty = 37.5*Get_Volt_R37()-27.5;
	if(!isLock){
		if(page==1)	sprintf(LCD_buf,"     P=%d%%",set_pwm_duty);
		TIM2->CCR2 = set_pwm_duty;
	}
}
/* TIM17
************************************************************
void HAL_TIM_IC_CaptureCallback(TIM_HandleTypeDef *htim);
double Get_Speed_PA7(void);
************************************************************
*/
void HAL_TIM_IC_CaptureCallback(TIM_HandleTypeDef *htim){
	if(htim->Instance == TIM17){
		TIM17_PSC_now = TIM17->PSC;
		capture = HAL_TIM_ReadCapturedValue(&htim17,TIM_CHANNEL_1);
		TIM17->CCR1=0;
		frq = 80000000/((TIM17_PSC_now+1)*capture);
		speed = (frq*2*pi*R)/(100*K);
		HAL_TIM_IC_Start_IT(&htim17,TIM_CHANNEL_1);
	}
}
//double Get_Speed_PA7(void){
//	HAL_TIM_IC_Start_IT(&htim17,TIM_CHANNEL_1);
//	frq = 80000000/(TIM17_PSC_now+1)/capture;
//	speed = (frq*2*pi*R)/(100*K);
//	return speed;
//}

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
